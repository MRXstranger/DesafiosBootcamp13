import React from 'react';
import { render } from 'react-dom';

import App from './App';

// JSX: HTML dentro do JavaScript (Javascript XML)

render(<App />, document.getElementById('app'));