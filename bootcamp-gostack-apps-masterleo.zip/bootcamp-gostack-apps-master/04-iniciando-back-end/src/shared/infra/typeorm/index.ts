import { createConnections } from 'typeorm';

createConnections();
