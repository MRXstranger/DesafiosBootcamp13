export default interface IFindAllInMonthFromProviderDTO {
  provider_id: string;
  month: number;
  year: number;
}
