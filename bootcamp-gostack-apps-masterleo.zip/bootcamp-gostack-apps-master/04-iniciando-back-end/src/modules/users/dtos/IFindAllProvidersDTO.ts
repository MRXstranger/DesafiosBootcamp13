export default interface IFindAllProvidersDTO {
  except_user_id?: string;
}
